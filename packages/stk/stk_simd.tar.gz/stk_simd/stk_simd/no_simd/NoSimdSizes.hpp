#ifndef STK_SIMD_FW_SIZES_H
#define STK_SIMD_FW_SIZES_H

namespace stk {
namespace simd {
constexpr int ndoubles = 1;
constexpr int nfloats  = 2;
}
}

#endif
