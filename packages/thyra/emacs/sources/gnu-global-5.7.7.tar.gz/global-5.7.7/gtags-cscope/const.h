/* This file is generated automatically by convert.pl from gtags-cscope/manual.in. */
const char *progname = "gtags-cscope";
const char *usage_const = "Usage: gtags-cscope [-Cqv]\n";
const char *help_const = "Options:\n\
-C, --ignore-case\n\
       Ignore letter case when searching.\n\
-q, --quiet\n\
       Quiet mode.\n\
-v, --verbose\n\
       Verbose mode.\n\
See also:\n\
       GNU GLOBAL web site: http://www.gnu.org/software/global/\n\
";
